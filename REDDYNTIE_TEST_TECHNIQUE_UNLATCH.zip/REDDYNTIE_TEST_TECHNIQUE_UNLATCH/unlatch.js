describe('UNLATCH auto', () => {
  it('clicks the link "type"', () => {
    cy.visit('https://www.legalife.fr/') 
  })
 
  it('Connexion', function () {

      cy.get(':nth-child(2) > .link').click() // cette ligne permet de cliquer sur le bouton connexion  de la page d'accueil de l'application
      cy.get('.row').click() // Cette ligne clique sur le bouton "Connexion" pour vérifier si les champs sont renseigner
      cy.wait(1000) // petite pause cypress
      cy.get('#login-popup-login > .error').should('exist') // cette ligne vérifie, si on a bien le message d'erreur "Mot de passe incorrect Mot de passe oublié"
      cy.wait(1000) // petite pause cypress
      cy.get('.valid').type('kikolo@yopmail.com') // cette ligne tape le mail correct dans le champ "Mail"
      cy.wait(1000) // petite pause cypress
      cy.get('#login-popup-login > form > [name="password"]').type('9fhjdlp8888') // cette ligne tape un faut mot de passe dans le champ" Mot de passe"
      cy.wait(1000) // petite pause cypress
      cy.get('.row').click() // cette ligne clique sur le bouton  "Connecion"
      cy.wait(1000) // petite pause Cypress
      cy.get('#login-popup-login > .error').should('exist') // cette ligne vérifie, si on a bien encore et une fois le message d'erreur "Mot de passe incorrect Mot de passe oublié"
      cy.wait(2000)
      cy.get('#login-popup-login > form > [name="password"]').clear().type('9fhjdlp8') // cette ligne tape un mot de passe correct dans le champ" Mot de passe"
      cy.wait(2000) // petite pause cypress
      cy.get('.row').click() //  // cette ligne clique sur le bouton  "Connecion"
      cy.wait(1000) // petite pause cypress
      cy.get('#login-popup-login > .success').should('exist') // cette ligne vérifie que le message “Vous êtes connecté. Cette page va se rafraîchir" et j’accède sur l’application en mode connecté" est bein affiché avant la redirection dans la page du compte du client.
      

      
})

})